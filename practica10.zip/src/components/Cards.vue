<template>
<div>
  <div class="row mt-3">
                
            <div class="col-xs-12 col-sm-6 col-md-4">
				<div class="card">
					<img class="card-img-top" :src="$store.state.Card1.imagen" alt="">
					<div class="card-body text-center">
						<h5 class="card-title">{{$store.state.Card1.titulo}}</h5>
						<h6 class="card-subtitle text-muted mb-2">Subtitulo</h6>
						<p class="card-text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus magnam quia nesciunt, odit obcaecati dicta molestiae ullam.</p>
						<a href="cards2.html" class="btn btn-outline-primary">Más información</a>
					</div>
				</div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4">
				<div class="card">
					<img class="card-img-top" :src="$store.state.Card1.imagen" alt="">
					<div class="card-body text-center">
						<h5 class="card-title">{{$store.state.Card2.titulo}}</h5>
						<h6 class="card-subtitle text-muted mb-2">Subtitulo</h6>
						<p class="card-text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus magnam quia nesciunt, odit obcaecati dicta molestiae ullam.</p>
						<a href="cards2.html" class="btn btn-outline-primary">Más información</a>
					</div>
				</div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4">
				<div class="card">
					<img class="card-img-top" :src="$store.state.Card1.imagen" alt="">
					<div class="card-body text-center">
						<h5 class="card-title">{{$store.state.Card3.titulo}}</h5>
						<h6 class="card-subtitle text-muted mb-2">Subtitulo</h6>
						<p class="card-text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus magnam quia nesciunt, odit obcaecati dicta molestiae ullam.</p>
						<a href="cards2.html" class="btn btn-outline-primary">Más información</a>
					</div>
				</div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4">
				<div class="card">
					<img class="card-img-top" :src="$store.state.Card1.imagen" alt="">
					<div class="card-body text-center">
						<h5 class="card-title">{{$store.state.Card4.titulo}}</h5>
						<h6 class="card-subtitle text-muted mb-2">Subtitulo</h6>
						<p class="card-text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus magnam quia nesciunt, odit obcaecati dicta molestiae ullam.</p>
						<a href="cards2.html" class="btn btn-outline-primary">Más información</a>
					</div>
				</div>
            </div>

            <div class="col-xs-12 col-sm-6 col-md-4">
				<div class="card">
					<img class="card-img-top" :src="$store.state.Card1.imagen" alt="">
					<div class="card-body text-center">
						<h5 class="card-title">{{$store.state.Card5.titulo}}</h5>
						<h6 class="card-subtitle text-muted mb-2">Subtitulo</h6>
						<p class="card-text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Natus magnam quia nesciunt, odit obcaecati dicta molestiae ullam.</p>
						<a href="cards2.html" class="btn btn-outline-primary">Más información</a>
					</div>
				</div>
            </div>
</div>
</div>
</template>

<script>
import { useStore } from "vuex"
export default {
  name: 'App',
    setup(){
    const store = useStore();
    console.log(store.state.mensaje);

    return {
      ...store.state,
    }
  }
}
</script>

<style>

</style>