<template>
    <h1>{{ title }}</h1>
    <div class="row">
        <template v-for="meme in memes" :key="meme.id" >
        <Meme :meme="meme" />
        </template>
    </div>
</template>

<script>
import { onMounted, computed } from "vue";
import { useStore } from "vuex";
import Meme from "./Meme.vue";

export default {
    components: {
        Meme,
    },
    setup() {
        const store = useStore();
        onMounted(() =>{
            store.dispatch("getMemes");
        });
        
    const memes = computed(() => store.state.memes);

        return{
            title: store.state.titleApp,
            memes,
        };
    },
};
</script>

<style>  
h1{
    text-align: center;
}
</style>
